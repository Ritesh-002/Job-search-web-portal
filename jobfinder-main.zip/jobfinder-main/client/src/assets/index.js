import NoProfile from "./userprofile.png";
import HeroImage from "./hero.png";
import Google from "./google.png";
import Linkedin from "./linkedin.png";
import Youtube from "./youtube.png";
import WhatsApp from "./whatsapp.png";
import Twitter from "./twitter.png";
import Instagram from "./instagram.png";
import Spotify from "./spotify.png";
import Office from "./office.jpg";
import JobImg from "./job.jpg";
import Facebook from "./facebook.png";
import CodeWave from "./codewave.png";

export {
  CodeWave,
  NoProfile,
  Facebook,
  WhatsApp,
  Twitter,
  Instagram,
  Spotify,
  HeroImage,
  Google,
  Linkedin,
  Youtube,
  Office,
  JobImg,
};
